from django.shortcuts import render
from . models import restaurants
# Create your views here.
def index(request):

    return render(request, "index.html")



def restinfo(request):
    foods = restaurants.objects.all()
    return render(request, "Restaurantsinfo.html", {'foods': foods})
